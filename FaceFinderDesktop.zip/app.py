import tkinter as tk
from tkinter import filedialog
import face_recognition
import cv2
from PIL import Image
import webbrowser
import os
import uuid

def browse_image():
    file_path = filedialog.askopenfilename()
    if file_path:
        detect_faces(file_path)

def detect_faces(image_path):
    image = face_recognition.load_image_file(image_path)
    face_locations = face_recognition.face_locations(image)

    os.makedirs("faces", exist_ok=True)
    for i, face_location in enumerate(face_locations):
        top, right, bottom, left = face_location
        face_image = image[top:bottom, left:right]
        pil_image = Image.fromarray(face_image)
        filename = f"faces/face_{uuid.uuid4().hex[:8]}.jpg"
        pil_image.save(filename)
        web_search_face(filename)

def web_search_face(image_path):
    search_url = "https://www.google.com/searchbyimage/upload"
    webbrowser.open(search_url)

# GUI
root = tk.Tk()
root.title("Face Finder")
root.geometry("300x100")

browse_btn = tk.Button(root, text="Upload Image", command=browse_image)
browse_btn.pack(pady=20)

root.mainloop()
